<?php
// Heading 
$_['heading_title']      = 'Mans profils';

// Text
$_['text_account']       = 'Mans profils';
$_['text_my_account']    = 'Profila pamatinformācija';
$_['text_my_orders']     = 'Mani pasūtījumi';
$_['text_my_newsletter'] = 'Jaunumu un īpašo piedāvājumu izsūtne';
$_['text_edit']          = 'Labot profilu';
$_['text_password']      = 'Mainīt paroli';
$_['text_address']       = 'Adrešu grāmata';
$_['text_wishlist']      = 'Vēlmju saraksts';
$_['text_order']         = 'Pasūtījumu vēsture';
$_['text_download']      = 'Lejupielādes';
$_['text_reward']        = 'Uzkrātie punkti'; 
$_['text_return']        = 'Preču atgriešana'; 
$_['text_transaction']   = 'Transakcijas'; 
$_['text_newsletter']    = 'Labot izsūtnes uzstādījumus';
?>