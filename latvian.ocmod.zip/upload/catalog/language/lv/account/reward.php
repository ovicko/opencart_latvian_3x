<?php
// Heading 
$_['heading_title']      = 'Jūsu uzkrātie punkti';

// Column
$_['column_date_added']  = 'Pievienots';
$_['column_description'] = 'Apraksts';
$_['column_points']      = 'Punkti';

// Text
$_['text_account']       = 'Mans profils';
$_['text_reward']        = 'Uzkrātie punkti';
$_['text_total']         = 'Jūsu uzkrāto punktu daudzums ir:';
$_['text_empty']         = 'Dotajā mirklī Jums vel nav neviena uzkrāto punktu!';

$_['button_continue']    = 'Aizvērt logu';
?>