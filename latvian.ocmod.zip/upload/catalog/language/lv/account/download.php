<?php
// Heading 
$_['heading_title']   = 'Lejupielādes';

// Text
$_['text_account']    = 'Mans profils';
$_['text_downloads']  = 'Lejupielādes';
$_['text_order']      = 'Pasūtījuma Nr.:';
$_['text_date_added'] = 'Pievienots:';
$_['text_name']       = 'Vārds:';
$_['text_remaining']  = 'Atlicis ielādēt vel:';
$_['text_size']       = 'Lielums:';
$_['text_download']   = 'Saglabāt failu';
$_['text_empty']      = 'Dotajā mirklī Jums vel nav neviena lejupielādes failu!';

$_['button_continue'] = 'Aizvērt logu';
?>