<?php
// Heading 
$_['heading_title'] = 'Jaunākās preces';

// Text
$_['text_reviews']  = 'Balstīts uz %s atsauksmēs(m).'; 
?>