<?php
// Heading 
$_['heading_title'] = 'Drīzumā';

// Text
$_['text_reviews']  = 'Balstīts uz %s atsauksmēs(m).'; 
?>