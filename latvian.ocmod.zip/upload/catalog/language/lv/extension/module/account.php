<?php
// Heading 
$_['heading_title']    = 'Profils';

// Text
$_['text_register']    = 'Reģistrēties';
$_['text_login']       = 'Autorizēties';
$_['text_logout']      = 'Iziet';
$_['text_forgotten']   = 'Aizmirsāt paroli?';
$_['text_account']     = 'Mans profils';
$_['text_edit']        = 'Labot profilu';
$_['text_password']    = 'Mainīt paroli';
$_['text_wishlist']    = 'Vēlmju saraksts';
$_['text_order']       = 'Pasūtījumu vēsture';
$_['text_download']    = 'Lejupielādes';
$_['text_return']      = 'Preču atgriešana';
$_['text_transaction'] = 'Transakcijas';
$_['text_newsletter']  = 'Jaunumu izsūtne';
?>
