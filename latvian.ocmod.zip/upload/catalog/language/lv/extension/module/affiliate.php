<?php
// Heading 
$_['heading_title']    = 'Partneru profils';

// Text
$_['text_register']    = 'Reģistrēties';
$_['text_login']       = 'Autorizēties';
$_['text_logout']      = 'Iziet';
$_['text_forgotten']   = 'Aizmirsāt paroli?';
$_['text_account']     = 'Mans profils';
$_['text_edit']        = 'Labot profilu';
$_['text_password']    = 'Mainīt paroli';
$_['text_payment']     = 'Maksājuma veidi';
$_['text_tracking']    = 'Sekošana';
$_['text_transaction'] = 'Transakcijas';
?>
