<?php
$_['heading_title'] = 'Laipni aicināti %s';
?>