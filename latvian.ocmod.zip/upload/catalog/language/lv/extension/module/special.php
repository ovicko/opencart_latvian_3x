<?php
// Heading 
$_['heading_title'] = 'Īpašie piedāvājumi';

// Text
$_['text_reviews']  = 'Balstīts uz %s atsauksmēs(m).'; 
?>