<?php
// Heading 
$_['heading_title'] = 'Pirktākās preces';

// Text
$_['text_reviews']  = 'Balstīts uz %s atsauksmēs(m).'; 
?>