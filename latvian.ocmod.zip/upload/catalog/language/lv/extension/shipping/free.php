<?php
// Text
$_['text_title']       = 'Bezmaksas piegāde';
$_['text_description'] = 'Bezmaksas piegāde';
?>