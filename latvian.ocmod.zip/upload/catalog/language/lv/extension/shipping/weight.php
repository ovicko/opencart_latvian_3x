<?php
// Text
$_['text_title']  = 'Piegāde pēc svara';
$_['text_weight'] = 'Svars:'; 
?>