<?php
// Text
$_['text_title']       = 'Piegāde ar fiksēto likmi';
$_['text_description'] = 'Piegāde ar fiksēto likmi';
?>