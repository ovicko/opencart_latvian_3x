<?php
// Text
$_['text_title']       = 'Pasūtījumu izņemšu pats/e';
$_['text_description'] = 'Pasūtījumu izņemšu pats/e no veikala';
?>