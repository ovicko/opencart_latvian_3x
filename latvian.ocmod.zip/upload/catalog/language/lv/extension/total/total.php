<?php
$_['text_total'] = 'Kopā:';
?>