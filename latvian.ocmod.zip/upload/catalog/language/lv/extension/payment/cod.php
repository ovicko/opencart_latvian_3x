<?php
// Text
$_['text_title'] = 'Apmaksa pie piegādes';
?>