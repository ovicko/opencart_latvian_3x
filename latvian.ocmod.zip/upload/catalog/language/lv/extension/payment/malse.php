<?php
// Text
$_['text_title'] = 'Kredītkarte / Debetkarte (Mal\'s e-commerce)';
?>