<?php
// Text
$_['text_title']       = 'Kredītkarte / Debetkarte (SagePay)';
$_['text_description'] = 'Preču daudzums %s Reķina Nr.: %s';
?>