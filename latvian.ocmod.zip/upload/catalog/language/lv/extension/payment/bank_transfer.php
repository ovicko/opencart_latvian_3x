<?php
// Text
$_['text_title']       = 'Bankas pārskaitījums';
$_['text_instruction'] = 'Bankas pārskaitījuma instrukcija';
$_['text_description'] = 'Lūdzu, pārskaitiet kopējo pasūtījuma summu uz zemāk norādītiem bankas kontu(iem).';
$_['text_payment']     = 'Pasūtījums netiks apstrādāts, kamēr nauda netiks pārskaitīta mūsu maksājuma kontā.';
?>