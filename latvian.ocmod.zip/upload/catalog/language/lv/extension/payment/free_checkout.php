<?php
// Text
$_['text_title'] = 'Bezmaksas apstrāde';
?>