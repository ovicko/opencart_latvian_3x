<?php
// Text
$_['text_title'] = 'Kredītkarte / Debetkarte (Moneybookers)';
?>