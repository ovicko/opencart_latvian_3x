<?php
// Text
$_['text_all'] = 'Rādīt visu';
