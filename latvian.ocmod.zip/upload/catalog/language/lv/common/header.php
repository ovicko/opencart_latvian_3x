<?php
// Text
$_['text_home']     = 'Sākums';
$_['text_wishlist'] = 'Vēlmju saraksts (%s)';
$_['text_cart']     = 'Pirkumu grozs';
$_['text_items']    = '%s Prece(s) - %s';
$_['text_welcome']  = 'Sveicināts viesi! Šeit varat <a href="%s">autorizēties</a> vai <a href="%s">reģistrēties</a>.';
$_['text_logged']   = 'Jūs ienācāt kā <a href="%s">%s</a> <b>(</b> <a href="%s">Iziet</a> <b>)</b>';
$_['text_account']  = 'Mans profils';
$_['text_checkout'] = 'Noformēt pirkumu';
$_['text_location']      = 'Mūsu atrašanās vieta';
$_['text_shopping_cart'] = 'Pirkumu grozs';
$_['text_category']      = 'Preču grupas';
$_['text_register']      = 'Reģistrēties';
$_['text_login']         = 'Autorizēties';
$_['text_order']         = 'Pasūtījumu vēsture';
$_['text_transaction']   = 'Darījumi';
$_['text_download']      = 'Lejupielādes';
$_['text_logout']        = 'Iziet';
$_['text_search']        = 'Meklēt';
$_['text_all']           = 'Skatīt visu';
?>