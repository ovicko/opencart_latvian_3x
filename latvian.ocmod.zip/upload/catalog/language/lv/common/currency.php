<?php
// Text
$_['text_currency'] = 'Valūta';
