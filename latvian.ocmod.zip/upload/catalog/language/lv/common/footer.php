<?php
// Text
$_['text_information']  = 'Informācija';
$_['text_service']      = 'Klientu apkalpošana';
$_['text_extra']        = 'Palīgrīki';
$_['text_account']      = 'Profils';
$_['text_contact']      = 'Sazinieties ar mums';
$_['text_return']       = 'Atgriezt preci';
$_['text_sitemap']      = 'Vietnes karte';
$_['text_manufacturer'] = 'Zīmols';
$_['text_voucher']      = 'Dāvanu kartes';
$_['text_affiliate']    = 'Mūsu partneriem';
$_['text_special']      = 'Īpašie piedāvājumi';
$_['text_login']        = 'Autorizēties';
$_['text_order']        = 'Pasūtījumu vēsture';
$_['text_wishlist']     = 'Vēlmju saraksts';
$_['text_newsletter']   = 'Jaunumu izsūtne';
$_['text_powered']      = '&copy; %s %s<br />Darbojās uz: <a href="http://www.opencart.com">OpenCart</a>';
?>