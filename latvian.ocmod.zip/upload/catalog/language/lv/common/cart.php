<?php
// Text
$_['text_items']     = '%s prece(s) - %s';

$_['text_empty']     = 'Jūsu pirkumu grozs ir tukšs!';
$_['text_cart']      = 'Skatīt grozu';
$_['text_checkout']  = 'Noformēt pirkumu';
$_['text_recurring'] = 'Atkārtoti maksājumi';
