<?php
// Heading
$_['heading_title'] = 'Jūsu partnera profils ir veiksmīgi izveidots!';

// Text 
$_['text_approval'] = '<p>Paldies par reģistrāciju veikalā %s!</p><p>Jums tiks paziņots ar e-pasta starpniecību, tik līdz veikala administrācija aktivizēs Jūsu izveidoto profilu.</p><p>Ja Jums rodas kādi jautājumi saistībā ar šo programmu, lūdzu, sazinieties ar veikala <a href="%s">administrāciju</a>.</p>';
$_['text_account']  = 'Mans profils';
$_['text_success']  = 'Veiksmīgi';

$_['button_continue']    = 'Aizvērt logu';
?>