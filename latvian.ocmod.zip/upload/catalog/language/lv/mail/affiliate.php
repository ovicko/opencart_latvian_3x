<?php
// Text
$_['text_subject']  = '%s - Sadarbības partneru programma';
$_['text_welcome']  = 'Paldies, ka pievienojāties % sadarbības partneru programmai!';
$_['text_approval'] = 'Jūsu profilam ir nepieciešams apstiprinājums pirms Jūs varēsiet to lietot. Tiklīdz veikala administrācija to apstiprinās, Jūs varēsiet ienākt savā profilā, izmantojot savu e-pasta adresi un paroli, apmeklējot mūsu tīmekļa vietni:';
$_['text_services'] = 'Pēc autorizēšanās, Jūs varēsiet izveidot sekošanas kodus, sekot līdzi maksājumiem, transakcijām un labot profila informāciju.';
$_['text_thanks']   = 'Ar cieņu,';
?>