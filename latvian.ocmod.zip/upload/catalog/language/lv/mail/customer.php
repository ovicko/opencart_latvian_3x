<?php
// Text
$_['text_subject']  = '%s - Paldies par reģistrāciju.';
$_['text_welcome']  = 'Esiet laipni aicināti un paldies par reģistrāciju veikalā %s!';
$_['text_login']    = 'Jūsu profils ir veiksmīgi izveidots, tagad Jūs varat ienākt savā profilā, izmantojot savu e-pasta adresi un paroli, apmeklējot mūsu tīmekļa vietni:';
$_['text_approval'] = 'Jūsu profilam ir nepieciešams apstiprinājums pirms Jūs varēsiet to lietot. Tiklīdz veikala administrācija to apstiprinās, Jūs varēsiet ienākt savā profilā, izmantojot savu e-pasta adresi un paroli, apmeklējot mūsu tīmekļa vietni:';
$_['text_services'] = 'Pēc profila apstiprinājuma Jūs varēsiet ātri un ērti noformēt pasūtījumus, sekot līdzi pasūtījuma apstrādei, rakstīt atsauksmes, komentēt un saņemt veikala aktuālāko informāciju savā e-pastā.';
$_['text_thanks']   = 'Ar cieņu,,';
?>