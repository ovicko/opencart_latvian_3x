<?php
// Text
$_['text_subject']  = 'Jūs esat saņēmuši dāvanu karti no %s';
$_['text_greeting'] = 'Apsveicam! Jūs esat saņēmis(usi) dāvanu karti %s vērtībā!';
$_['text_from']     = 'Šo dāvanu karti jums sūta %s';
$_['text_message']  = 'Ar sekojošu ziņojumu';
$_['text_redeem']   = 'Lai izmantot šo dāvanu karti ir nepieciešams norakstīt sekojošu kodu: <b>%s</b>, kad to izdarījāt noklikšķiniet uz zemāk redzamo saiti. Izvēlaties sev vēlamo preci, ielieciet to pirkumu grozā un ievadiet dāvanu kartes kodu. Dāvanu kartes kodu ir nepieciešams ievadīt pirkumu grozā pirms, Jūs noformējat savu pirkumu!';
$_['text_footer']   = 'Lūdzu, atbildiet uz šo e-pasta ziņojumu, ja jums ir kādi jautājumi.';
?>