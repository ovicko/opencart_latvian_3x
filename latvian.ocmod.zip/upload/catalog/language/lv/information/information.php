<?php
// Text
$_['text_error'] = 'Uzmanību: Informācijas vietne nav atrasta!';
?>