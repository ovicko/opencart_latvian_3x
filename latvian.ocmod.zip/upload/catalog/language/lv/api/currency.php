<?php
// Text
$_['text_success']     = 'Jūs sekmīgi nomainījāt savu valūtu!';

// Error
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_currency']   = 'Uzmanību!: Valūtas kods ir nederīgs!';
