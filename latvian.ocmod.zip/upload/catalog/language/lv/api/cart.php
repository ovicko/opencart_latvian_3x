<?php
$_['text_success']    = 'Pabeigts: Pirkumu grozs ir sekmīgi mainīts!';

// Error
$_['error_stock']     = 'Uzmanību: Prece, kas apzīmēti ar *** nav pieejama šādā daudzumā vai pat reiz nav noliktavā!';
$_['error_minimum']   = 'Uzmanību: Minimālais pasūtījuma apjoms priekš %s ir %s vienības!';	
$_['error_required']  = 'Uzmanību: %s nepieciešams!';
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_store']    = 'Šī prece nav nopērkama jūsu izvēlētajā veikalā!';

$_['button_continue']       = 'Aizvēt logu';
?>