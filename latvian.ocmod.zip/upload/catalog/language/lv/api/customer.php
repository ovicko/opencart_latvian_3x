<?php
// Text
$_['text_success']       = 'Jūs esat sekmīgi pabeiguši klientu rediģēšanu';

// Error
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_customer']     = 'Jums ir jāizvēlas klients!';
$_['error_firstname']    = 'Vārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_lastname']     = 'Uzvārdam jābūt no 1 līdz 32 rakstzīmēm!';
$_['error_email']        = 'E-pasta adrese nav derīga!';
$_['error_telephone']    = 'Telefona numuram jābūt no 3 līdz 32 rakstzīmēm!';
$_['error_custom_field'] = '%s ir obligāti jānorāda!';