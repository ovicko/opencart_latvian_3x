<?php
// Text
$_['text_success'] = 'API sesija ir veiksmīgi uzsākta!';

// Error
$_['error_key']    = 'Uzmanību! Nederīga API Atslēga!';
$_['error_ip']     = 'Uzmanību! Jūsu IP adresei %s nav atļauts piekļūt šim API!';