<?php
// Text
$_['text_success']     = 'Jūsu bonusa punktu atlaide ir sekmīgi piemērota!';

// Error
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_reward']     = 'Uzmanību! Lūdzu norādiet bonusa punktu skaitu, kurus vēlaties izmantot!';
$_['error_points']     = 'Uzmanību! %s ir vairāk nekā jūsu kontā pieejamie bonusa punkti!';
$_['error_maximum']    = 'Uzmanību! Maksimālais pieejamo bonusa punktu skaits ir %s!';
