<?php
// Text
$_['text_success']     = 'Jūsu dāvanu kartes atlaide ir sekmīgi piemērota!';
$_['text_cart']        = 'Jūs sekmīgi veicāt izmaiņas jūsu pasūtījuma grozā!';
$_['text_for']         = '%s Dāvanu karte, saņems %s';

// Error
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_voucher']    = 'Uzmanību! Dāvanu karte ir vai nu nederīga, vai arī tās kontā nepietiek līdzekļu!';
$_['error_to_name']    = 'Saņēmēja vārda garumam ir jābūt no 1 līdz 64 rakstzīmēm!';
$_['error_from_name']  = 'Jūsu vārda garumam ir jābūt no 1 līdz 64 rakstzīmēm!';
$_['error_email']      = 'Nederīga E-pasta adrese!';
$_['error_theme']      = 'Lūdzu, izvēlieties noformējumu!';
$_['error_amount']     = 'Summai jābūt no %s līdz %s!';
