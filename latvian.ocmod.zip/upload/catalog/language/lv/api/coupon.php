<?php
// Text
$_['text_success']     = 'Kupona atlaide ir sekmīgi piemērota!';

// Error
$_['error_permission']     = 'Uzmanību! Jums nav atļauts piekļūt API!';
$_['error_coupon']     = 'Uzmanību! Kupons vai nu nav derīgs, vai arī ir sasniedzis izmantojamo reižu skaitu!';
